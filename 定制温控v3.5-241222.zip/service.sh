MODDIR=${0%/*}

DEVICE=$(getprop ro.product.device)
config="/data/vendor/thermal/config/"

wait_until_login() {
    while [ "$(getprop sys.boot_completed)" != "1" ]; do
        sleep 1
    done
    until [ -d "/data/data/android" ]; do
        sleep 1
    done
}

lock_val() {
	for p in $2; do
		if [ -f "$p" ]; then
			chown root:root "$p"
			chmod 0666 "$p"
			echo "$1" >"$p"
			chmod 0444 "$p"
		fi
	done
}

qcom_Gpu() {
	MIN_PWRLVL=$(($(cat /sys/class/kgsl/kgsl-3d0/num_pwrlevels) - 1))
	lock_val "$MIN_PWRLVL" /sys/class/kgsl/kgsl-3d0/default_pwrlevel
	lock_val "$MIN_PWRLVL" /sys/class/kgsl/kgsl-3d0/min_pwrlevel
	lock_val "0" /sys/class/kgsl/kgsl-3d0/max_pwrlevel
	lock_val "0" /sys/class/kgsl/kgsl-3d0/thermal_pwrlevel
	lock_val "0" /sys/class/kgsl/kgsl-3d0/throttling
}

wait_until_login
chmod 000 /data/system/mcd/df
chattr -i $config*
rm -rf $config*
