config="/data/vendor/thermal/config/"
chattr -i $config*
rm -rf $config*