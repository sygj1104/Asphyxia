MODDIR=${0%/*}
DEVICE=$(getprop ro.product.device)

key_click() {
while true; do sleep 0.5
keyInfo=$(getevent -qlc 1 | grep KEY_VOLUME)
if [ "$keyInfo" == "" ]; then
continue
else
UpKey=$(echo $keyInfo | grep KEY_VOLUMEUP)
[ "$UpKey" != "" ] && return 0 || return 1
break
fi
done
}

sed -i '/^description=/s/=.*$/=/' "$MODDIR/module.prop"
sed -i '/^cp/d' "$MODDIR/service.sh"

case "$DEVICE" in
    "unicorn")
        sed -i "/description=/s/$/[机型：Xiaomi 12SPro] /" "$MODDIR"/module.prop
        ;;
    "diting")
        sed -i "/description=/s/$/[机型：REDMI K50Ultra] /" "$MODDIR"/module.prop
        ;;
    "socrates")
        sed -i "/description=/s/$/[机型：REDMI K60Pro] /" "$MODDIR"/module.prop
        ;;
    "dada")
        sed -i "/description=/s/$/[机型：Xiaomi 15] /" "$MODDIR"/module.prop
        ;;
    "haotian")
        sed -i "/description=/s/$/[机型：Xiaomi 15Pro] /" "$MODDIR"/module.prop
        ;;
    "miro")
        sed -i "/description=/s/$/[机型：REDMI K80Pro] /" "$MODDIR"/module.prop
        ;;
    "zorn")
        sed -i "/description=/s/$/[机型：REDMI K80] /" "$MODDIR"/module.prop
        ;;
esac

echo "-                  请选择温控模式"
echo " 音量↑:[夏日限定][深度定制]   音量↓:[极致性能][丧心病狂]"

if key_click; then
   echo "              ✔"
   NX=1
else
   echo "                                       ✔"
   NX=0
fi

if [[ "$NX" -eq 1 ]]; then
  echo "     音量↑:[夏日限定]            音量↓:[深度定制]"

  if key_click; then
    echo "              ✔"
    echo "cp /data/adb/modules/Eclipse/夏日限定/$DEVICE/* /data/vendor/thermal/config/" >> "$MODDIR/service.sh"
    sed -i "/description=/s/$/[😇当前温控模式：夏日限定🥰] /" "$MODDIR"/module.prop
  else
    echo "                                        ✔"
    echo "cp /data/adb/modules/Eclipse/深度定制/$DEVICE/* /data/vendor/thermal/config/" >> "$MODDIR/service.sh"
    sed -i "/description=/s/$/[😇当前温控模式：深度定制🥰] /" "$MODDIR"/module.prop
  fi
fi

if [[ "$NX" -eq 0 ]]; then
  echo "     音量↑:[极致性能]            音量↓:[丧心病狂]"

  if key_click; then
    echo "              ✔"
    echo "cp /data/adb/modules/Eclipse/极致性能/$DEVICE/* /data/vendor/thermal/config/" >> "$MODDIR/service.sh"
    sed -i "/description=/s/$/[😇当前温控模式：极致性能🥰] /" "$MODDIR"/module.prop
  else
    echo "                                       ✔"
    echo "cp /data/adb/modules/Eclipse/丧心病狂/$DEVICE/* /data/vendor/thermal/config/" >> "$MODDIR/service.sh"
    sed -i "/description=/s/$/[😇当前温控模式：丧心病狂😡] /" "$MODDIR"/module.prop
  fi
fi

sh "$MODDIR"/service.sh
echo "- 成功更改模式😋"