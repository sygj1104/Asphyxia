# 设置权限
set_perm_recursive "$MODPATH" 0 0 0755 0755
DEVICE=$(getprop ro.product.device)
mod="/data/adb/modules"
cool="$MODPATH/夏日限定"
pro="$MODPATH/深度定制"
extreme="$MODPATH/极致性能"
danger="$MODPATH/丧心病狂"

key_click() {
while true; do sleep 0.5
keyInfo=$(getevent -qlc 1 | grep KEY_VOLUME)
if [ "$keyInfo" == "" ]; then
continue
else
UpKey=$(echo $keyInfo | grep KEY_VOLUMEUP)
[ "$UpKey" != "" ] && return 0 || return 1
break
fi
done
}

case "$DEVICE" in
    "unicorn")
        for dzwk in "$cool" "$pro" "$extreme" "$danger"; do
            for wk in "$dzwk"/*; do
                name=$(basename "$wk")
                if [ "$name" != "unicorn" ]; then
                    rm -rf "$wk"
                fi               
            done
        done
        sed -i "/description=/s/$/[机型：Xiaomi 12SPro] /" "$MODPATH"/module.prop
        ;;
    "diting")
        for dzwk in "$cool" "$pro" "$extreme" "$danger"; do
            for wk in "$dzwk"/*; do
                name=$(basename "$wk")
                if [ "$name" != "diting" ]; then
                    rm -rf "$wk"
                fi
            done
        done
        sed -i "/description=/s/$/[机型：REDMI K50Ultra] /" "$MODPATH"/module.prop
        ;;
    "socrates")
        for dzwk in "$cool" "$pro" "$extreme" "$danger"; do
            for wk in "$dzwk"/*; do
                name=$(basename "$wk")
                if [ "$name" != "socrates" ]; then
                    rm -rf "$wk"
                fi
            done
        done
        sed -i "/description=/s/$/[机型：REDMI K60Pro] /" "$MODPATH"/module.prop
        ;;
    "dada")
        for dzwk in "$cool" "$pro" "$extreme" "$danger"; do
            for wk in "$dzwk"/*; do
                name=$(basename "$wk")
                if [ "$name" != "dada" ]; then
                    rm -rf "$wk"
                fi               
            done
        done
        sed -i "/description=/s/$/[机型：Xiaomi 15] /" "$MODPATH"/module.prop
        ;;
    "haotian")
        for dzwk in "$cool" "$pro" "$extreme" "$danger"; do
            for wk in "$dzwk"/*; do
                name=$(basename "$wk")
                if [ "$name" != "haotian" ]; then
                    rm -rf "$wk"
                fi              
            done
        done
        sed -i "/description=/s/$/[机型：Xiaomi 15Pro] /" "$MODPATH"/module.prop
        ;;
    "miro")
        for dzwk in "$cool" "$pro" "$extreme" "$danger"; do
            for wk in "$dzwk"/*; do
                name=$(basename "$wk")
                if [ "$name" != "miro" ]; then
                    rm -rf "$wk"
                fi            
            done
        done
        sed -i "/description=/s/$/[机型：REDMI K80Pro] /" "$MODPATH"/module.prop
        ;;
    "zorn")
        for dzwk in "$cool" "$pro" "$extreme" "$danger"; do
            for wk in "$dzwk"/*; do
                name=$(basename "$wk")
                if [ "$name" != "zorn" ]; then
                    rm -rf "$wk"
                fi
            done
        done
        sed -i "/description=/s/$/[机型：REDMI K80] /" "$MODPATH"/module.prop
        ;;
    *)
        abort "- ❗未识别当前机型温控文件，停止刷入❗"
        ;;
esac

echo "-                  请选择温控模式"
echo " 音量↑:[夏日限定][深度定制]   音量↓:[极致性能][丧心病狂]"

if key_click; then
   echo "              ✔"
   NX=1
else
   echo "                                       ✔"
   NX=0
fi

if [[ "$NX" -eq 1 ]]; then
  echo "     音量↑:[夏日限定]            音量↓:[深度定制]"

  if key_click; then
    echo "              ✔"
    echo "cp /data/adb/modules/Eclipse/夏日限定/$DEVICE/* /data/vendor/thermal/config/" >> "$MODPATH/service.sh"
    sed -i "/description=/s/$/[😇当前温控模式：夏日限定🥰] /" "$MODPATH"/module.prop
  else
    echo "                                        ✔"
    echo "cp /data/adb/modules/Eclipse/深度定制/$DEVICE/* /data/vendor/thermal/config/" >> "$MODPATH/service.sh"
    sed -i "/description=/s/$/[😇当前温控模式：深度定制🥰] /" "$MODPATH"/module.prop
  fi
fi

if [[ "$NX" -eq 0 ]]; then
  echo "     音量↑:[极致性能]            音量↓:[丧心病狂]"

  if key_click; then
    echo "              ✔"
    echo "cp /data/adb/modules/Eclipse/极致性能/$DEVICE/* /data/vendor/thermal/config/" >> "$MODPATH/service.sh"
    sed -i "/description=/s/$/[😇当前温控模式：极致性能🥰] /" "$MODPATH"/module.prop
  else
    echo "                                       ✔"
    echo "cp /data/adb/modules/Eclipse/丧心病狂/$DEVICE/* /data/vendor/thermal/config/" >> "$MODPATH/service.sh"
    sed -i "/description=/s/$/[😇当前温控模式：丧心病狂😡] /" "$MODPATH"/module.prop
  fi
fi

echo "*************************************************"
echo "-             是否添加[禁止GPU Boost]"
echo "-   若有降压则必须选择[是]     若无降压建议选择[否]"
echo "         音量↑:[是]             音量↓:[否]"

if key_click; then
    echo "             ✔"
    echo "qcom_Gpu" >> "$MODPATH/service.sh"
else
    echo "                                   ✔"
fi

echo "*************************************************"

echo "- 请立即重启以享用模块😇"
